import "./settings.js"

import makeWASocket, {
    fetchLatestBaileysVersion,
    useMultiFileAuthState
} from "yowtech"

import pino from "pino"

import logger from "./Cube/Lib/Logger.js"
import Loader from "./Cube/Lib/Loader.js"
import Database from "./Cube/Lib/Database.js"
import JadiBotManager from "./Cube/Lib/JadiBotManager.js"
import EventHandler from "./Cube/Core/EventHandler.js"

let jadiBotManager = null


function isConnectionClosedError(error) {
    const statusCode =
        error?.output?.statusCode ||
        error?.data?.statusCode ||
        error?.statusCode

    return statusCode === 428 ||
        /connection closed|precondition required/i.test(
            String(error?.message || error?.output?.payload?.message || "")
        )
}

function wait(ms) {
    return new Promise(resolve => setTimeout(resolve, ms))
}

async function requestPairingCodeSafely(sock, phoneNumber, customCode) {
    let connectingSeen = false

    const onConnectionUpdate = update => {
        if (update?.connection === "connecting") {
            connectingSeen = true
        }
    }

    sock.ev.on("connection.update", onConnectionUpdate)

    try {
        // requestPairingCode harus dikirim ketika socket sudah mulai membuka
        // koneksi. Menunggu event ini lebih aman daripada fixed delay 3 detik.
        for (let i = 0; i < 30 && !connectingSeen; i += 1) {
            await wait(500)
        }

        await wait(1500)

        let lastError
        for (let attempt = 1; attempt <= 3; attempt += 1) {
            try {
                return await sock.requestPairingCode(phoneNumber, customCode)
            } catch (error) {
                lastError = error

                if (!isConnectionClosedError(error) || attempt === 3) {
                    throw error
                }

                logger.warn(
                    `Socket tertutup saat meminta pairing code (percobaan ${attempt}/3). Mencoba ulang...`
                )
                await wait(attempt * 3000)
            }
        }

        throw lastError
    } finally {
        sock.ev.off?.("connection.update", onConnectionUpdate)
    }
}

async function start() {

    logger.banner()

    logger.info(
        "Starting SingulaRita..."
    )


    const {
        state,
        saveCreds
    } =
        await useMultiFileAuthState(
            "./session"
        )


    const {
        version
    } =
        await fetchLatestBaileysVersion()




    const sock =
        makeWASocket({

            version: [2, 3000, 1050908835],

            auth:
                state,

            browser: [
                "Ubuntu",
                "Chrome",
                "21.0.04"
            ],

            printQRInTerminal:
                false,

            markOnlineOnConnect:
                true,

            syncFullHistory:
                false,

            defaultQueryTimeoutMs:
                60000,

            logger:
                pino({
                    level:
                        "silent"
                })

        })

    const connectionControl = {
        stopping: false,
        pairing: !state.creds.registered,
        sessionRegistered: Boolean(state.creds.registered),
        hasOpened: false
    }


    /*
     * ============================================
     * GROUP METADATA CACHE
     * ============================================
     *
     * Tidak melakukan groupMetadata()
     * setiap pesan.
     */

    sock.groupMetadataCache =
        new Map()


    /*
     * ============================================
     * GROUP UPDATE
     * ============================================
     *
     * Saat group berubah,
     * refresh metadata cache.
     */

    sock.ev.on(
        "groups.update",
        async updates => {

            if (
                !Array.isArray(
                    updates
                )
            ) {
                return
            }


            for (
                const update
                of updates
            ) {

                if (
                    !update?.id
                ) {
                    continue
                }


                try {

                    const metadata =
                        await sock.groupMetadata(
                            update.id
                        )


                    if (
                        metadata
                    ) {

                        sock.groupMetadataCache.set(
                            update.id,
                            metadata
                        )

                    }

                } catch {}

            }

        }
    )


    /*
     * ============================================
     * DATABASE
     * ============================================
     */

    const db = {

        users:
            await Database.users(),

        otp:
            await Database.otp(),

        groups:
            await Database.groups(),

        settings:
            await Database.settings(),

        saveSettings:
            Database.saveSettings

    }


    /*
     * ============================================
     * YOWTECH CONTEXT
     * ============================================
     */

    const Yowtech = {

        sock,

        db,

        store: {
            contacts: {},
            presences: {}
        },
        config: {},

        logger,

        connectionControl,

        plugins:
            Loader,

        start

    }

    if (!jadiBotManager) {
        jadiBotManager = new JadiBotManager({
            db,
            plugins: Loader,
            logger
        })
    } else {
        jadiBotManager.updateRuntime({ db, plugins: Loader, logger })
    }
    Yowtech.jadibotManager = jadiBotManager


    /*
     * ============================================
     * LOAD PLUGINS
     * ============================================
     */

    await Loader.loadPlugins()


    logger.success(
        `Loaded ${Loader.getPlugins().length} plugins`
    )


    /*
     * ============================================
     * EVENTS
     * ============================================
     */

    EventHandler(
        Yowtech
    )

    await jadiBotManager.restore()


    /*
     * ============================================
     * CREDENTIALS
     * ============================================
     */

    sock.ev.on(
        "creds.update",
        saveCreds
    )


    /*
     * ============================================
     * PAIRING
     * ============================================
     */

    if (
        !state.creds.registered
    ) {

        logger.info(
            "Generating Pairing Code..."
        )


        const code = await requestPairingCodeSafely(
            sock,
            global.yB.botNumber.replace(/\D/g, ""),
            global.yB.botPairing
        )


        logger.success(
            `Pairing Code : ${code}`
        )

    }


    /*
     * ============================================
     * PLUGIN WATCHER
     * ============================================
     */

    Loader.watchPlugins()


    logger.success(
        "SingulaRita is ready."
    )


    return sock

}


start().catch(
    error => {

        console.error(
            error
        )

        logger.logError(
            error
        )

    }
)
