global.yB = {
  botName: "Yowtech Bot",
  botNumber: "6281234567890",
  botVersion: "1.0.0",
  botProfile: "https://",
  botPrefix: [".", "/"],
  botPairing: "YOWTECH",

  ownerName: "Owner",
  ownerNumber: "6281234567890",
  ownerProfile: "https://",

  stickerPack: "Yowtech Bot",
  stickerAuthor: "Yowtech",

  sosmedInstagram: "https://",
  sosmedGithub: "https://github.com/Yowtech/Base",

  channelName: "Yowtech Bot",
  channelJid: "",
  channelId: 1,
  channelUrl: ""
}
