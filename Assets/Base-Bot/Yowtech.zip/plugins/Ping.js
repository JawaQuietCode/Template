function formatUptime(totalSeconds) {
    const seconds = Math.max(0, Math.floor(totalSeconds))
    const days = Math.floor(seconds / 86_400)
    const hours = Math.floor((seconds % 86_400) / 3_600)
    const minutes = Math.floor((seconds % 3_600) / 60)
    const remainingSeconds = seconds % 60

    return [
        days ? `${days}h` : "",
        `${hours}j`,
        `${minutes}m`,
        `${remainingSeconds}d`
    ].filter(Boolean).join(" ")
}

function getMessageAgeMs(timestamp) {
    const value = Number(timestamp)
    if (!Number.isFinite(value) || value <= 0) return null

    const timestampMs = value < 1e12 ? value * 1000 : value
    return Math.max(0, Date.now() - timestampMs)
}

function formatMs(value) {
    return value < 10 ? value.toFixed(2) : value.toFixed(0)
}

export default {
    name: "Ping",
    command: ["ping", "p"],
    category: "Main",
    description: [
        "*Ping*",
        "`Example :`",
        ".ping",
        "> Memeriksa respons, latensi, uptime, dan penggunaan memory bot.",
        "> Alias: .p"
    ].join("\n"),
    menuVisible: true,
    permission: {
        owner: false,
        admin: false,
        botAdmin: false,
        group: false,
        private: false,
        premium: false
    },
    cooldown: 3,
    async execute(ctx) {
        const { m } = ctx
        const messageAge = getMessageAgeMs(m.timestamp)
        const heapUsedMb = process.memoryUsage().heapUsed / (1024 * 1024)
        const latencyText = messageAge === null
            ? "Tidak tersedia"
            : `${formatMs(messageAge)} ms`

        const text = [
            "Pong!",
            `• Latensi pesan masuk: ${latencyText}`,
            `• Uptime: ${formatUptime(process.uptime())}`,
            `• Heap terpakai: ${heapUsedMb.toFixed(1)} MB`
        ].join("\n")

        return m.reply(text)
    }
}
