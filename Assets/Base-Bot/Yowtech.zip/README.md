# Yowtech Bot Template

Template bot WhatsApp berbasis Yowtech Baileys fork.

Template ini berisi sistem inti dari SC Yowtech, tanpa plugin produksi. Plugin bawaan hanya `Ping.js` sebagai contoh struktur plugin.

## Struktur

```text
.
├── Assets/
│   └── Environment/
├── Cube/
│   ├── Core/
│   └── Lib/
├── database/
├── plugins/
│   └── Ping.js
├── index.js
├── package.json
├── settings.js
└── README.md
```

## Instalasi

1. Edit `settings.js` dan isi `botNumber`, `ownerNumber`, serta konfigurasi lain.
2. Install dependency:

```bash
npm install
```

3. Jalankan bot:

```bash
npm start
```

4. Tambahkan plugin baru ke folder `plugins/`. Plugin akan dimuat dan di-hot-reload oleh sistem.

## Plugin contoh

```text
.ping
.p
```

> Memeriksa respons, latensi, uptime, dan penggunaan memory bot.
