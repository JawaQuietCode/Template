import PluginHooks from "../Helpers/PluginHooks.js"

export default async function Call(Yowtech, calls) {
    const { sock, logger, config } = Yowtech

    try {
        if (!Array.isArray(calls)) {
            calls = [calls]
        }

        for (const call of calls) {
            const {
                id,
                from,
                status,
                isVideo,
                isGroup
            } = call

            logger.info(
                `[Call] ${from} | ${isVideo ? "Video" : "Voice"} | ${status}`
            )

            // Contoh Anti Call
            if (config?.antiCall && status === "offer") {
                await sock.sendMessage(from, {
                    text: "⚠️ Maaf, bot tidak menerima panggilan."
                })

                await sock.rejectCall(id, from)
            }

            // Hook plugin: onCall({ call, id, from, status, isVideo, isGroup })
            await PluginHooks(Yowtech, "onCall", {
                call,
                id,
                from,
                status,
                isVideo,
                isGroup
            })
        }

    } catch (error) {
        logger.error(error)
    }
}
