import PluginHooks from "../Helpers/PluginHooks.js"

export default async function MessagesReaction(Yowtech, reactions) {
    const { logger } = Yowtech

    try {
        if (!Array.isArray(reactions)) {
            reactions = [reactions]
        }

        for (const reaction of reactions) {
            const {
                key,
                reaction: emoji,
                senderTimestampMs
            } = reaction

            logger.info(
                `[Reaction] ${key.remoteJid} | ${key.participant || key.remoteJid} -> ${emoji.text}`
            )

            // Hook plugin: onReaction({ reaction, key, emoji })
            await PluginHooks(Yowtech, "onReaction", {
                reaction,
                key,
                emoji
            })

            if (senderTimestampMs) {
                logger.info(
                    `[Reaction Time] ${new Date(Number(senderTimestampMs))}`
                )
            }
        }

    } catch (error) {
        logger.error(error)
    }
}
