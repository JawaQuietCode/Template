export default async function PresenceUpdate(Yowtech, update) {
    const { logger, store } = Yowtech

    try {
        const { id, presences } = update

        if (!presences) return

        for (const [jid, presence] of Object.entries(presences)) {
            const lastKnownPresence =
                presence.lastKnownPresence ?? "unknown"

            const lastSeen =
                presence.lastSeen
                    ? new Date(presence.lastSeen * 1000)
                    : null

            if (store?.presences) {
                store.presences[jid] = presence
            }



            if (lastSeen) {
                logger.info(
                    `[Last Seen] ${jid} -> ${lastSeen}`
                )
            }
        }

        for (const plugin of Yowtech.plugins?.getPlugins?.() || []) {
            if (typeof plugin?.onPresenceUpdate !== "function") continue
            try {
                await plugin.onPresenceUpdate({
                    sock: Yowtech.sock,
                    db: Yowtech.db,
                    store: Yowtech.store,
                    logger,
                    id,
                    presences
                })
            } catch (error) {
                logger?.error?.(error)
            }
        }

    } catch (error) {
        logger.error(error)
    }
}
