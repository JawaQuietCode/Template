import fs from "node:fs"
import { sendPreview } from "../../Lib/Preview.js"
import { sendGroupEventCard } from "../../Lib/GroupCard.js"
import * as JidResolver from "../../Lib/JidResolver.js"
import { mentionToken, phoneDigits, phoneJid, preserveMentionJid, uniqueMentionJids } from "../../Lib/MentionJid.js"

const recentParticipantEvents = new Map()
const DUPLICATE_WINDOW = 8_000

function isDuplicateParticipantEvent(groupId, action, jid) {
    const key = `${groupId}|${action}|${jid || "unknown"}`
    const now = Date.now()
    const previous = recentParticipantEvents.get(key) || 0

    recentParticipantEvents.set(key, now)

    for (const [eventKey, timestamp] of recentParticipantEvents) {
        if (now - timestamp > DUPLICATE_WINDOW) {
            recentParticipantEvents.delete(eventKey)
        }
    }

    return now - previous < DUPLICATE_WINDOW
}

function loadJSON(file) {
    try {
        if (!fs.existsSync(file)) return {}
        return JSON.parse(fs.readFileSync(file, "utf8"))
    } catch {
        return {}
    }
}

function memberIds(member) {
    if (typeof member === "string") return [member]
    return [member?.id, member?.jid, member?.phoneNumber].filter(Boolean)
}

function numberOf(jid) {
    return String(jid || "").split("@")[0].split(":")[0]
}

function findMetadataParticipant(jid, metadata) {
    const participants = metadata?.participants || []
    const exact = participants.find(item =>
        memberIds(item).some(candidate =>
            String(candidate || "").split(":")[0].toLowerCase() === String(jid || "").split(":")[0].toLowerCase()
        )
    )
    if (exact) return exact

    return participants.find(item =>
        memberIds(item).some(candidate => numberOf(candidate) === numberOf(jid))
    ) || null
}

function participantJid(member, jid, metadata) {
    const metadataMember = findMetadataParticipant(jid, metadata)
    const originalJids = [
        typeof member === "string" ? member : member?.id,
        member?.jid,
        metadataMember?.id,
        metadataMember?.jid,
        jid
    ]
    const original = originalJids.map(preserveMentionJid).find(Boolean)
    if (original) return original

    const phoneValues = [
        typeof member === "string" ? member : null,
        member?.phoneNumber,
        metadataMember?.phoneNumber,
        JidResolver.getPhone(member?.id),
        JidResolver.getPhone(metadataMember?.id),
        JidResolver.getPhone(jid)
    ]
    return phoneValues.map(phoneJid).find(Boolean) || null
}

function displayPhone(member, jid, metadata) {
    const metadataMember = findMetadataParticipant(jid, metadata)
    const values = [
        typeof member === "string" ? member : null,
        member?.phoneNumber,
        metadataMember?.phoneNumber,
        JidResolver.getPhone(member?.id),
        JidResolver.getPhone(metadataMember?.id),
        JidResolver.getPhone(jid),
        /@(s\.whatsapp\.net|c\.us)$/i.test(String(jid || "")) ? jid : null
    ]
    const digits = values.map(phoneDigits).find(Boolean)
    return digits ? `+${digits}` : "Nomor tidak tersedia"
}

function memberName(member, jid, metadata, sock) {
    if (typeof member === "object") {
        const directName = member.notify || member.name || member.verifiedName || member.pushName
        if (directName) return directName
    }

    const participant = findMetadataParticipant(jid, metadata)

    if (participant) {
        return participant.notify || participant.name || participant.verifiedName || JidResolver.getUsername(jid) || "Member"
    }

    const contact = sock?.contacts?.[jid] || sock?.contacts?.[String(jid).split("@")[0]]
    return contact?.notify || contact?.name || contact?.verifiedName || JidResolver.getUsername(jid) || "Member"
}

function replaceText(text, userJid, metadata, adminJid) {
    const userTag = mentionToken(userJid) || "@Member"
    const adminTag = mentionToken(adminJid) || "Admin"
    return String(text || "")
        .replace(/@user|\{user\}/gi, userTag)
        .replace(/@member|\{member\}/gi, userTag)
        .replace(/@admin/gi, adminTag)
        .replace(/{admin}/gi, adminTag)
        .replace(/@group/gi, metadata?.subject || "grup ini")
        .replace(/{group}/gi, metadata?.subject || "grup ini")
}

async function sendLegacyView({ sock, chat, jid, author, metadata, data }) {
    const text = replaceText(
        data?.text,
        jid,
        metadata,
        author
    )
    const mentions = uniqueMentionJids([jid, author])

    const message = {
        mentions,
        contextInfo: { mentionedJid: mentions }
    }
    if (data?.image && fs.existsSync(data.image)) {
        message.image = data.image
        message.caption = text
    } else {
        message.text = text
    }
    await sendPreview(sock, chat, message)
}

export default async function GroupParticipants(Yowtech, update) {
    const { sock, logger, db } = Yowtech
    const { id, participants = [], action, author } = update || {}
    if (!sock || !id || !action) return

    try {
        const metadata = await sock.groupMetadata(id)
        JidResolver.remember(metadata)
        db.groups ??= {}
        const group = db.groups[id] || {}
        const intro = loadJSON("./database/intro.json")[id] || ""
        const views = {
            promote: loadJSON("./Assets/Environment/Promote.json"),
            demote: loadJSON("./Assets/Environment/Demote.json")
        }
        const customEventTypes = new Set(
            Yowtech.plugins.getPlugins()
                .filter(plugin => typeof plugin?.onParticipantUpdate === "function")
                .map(plugin => plugin.handlesParticipantEvent)
                .filter(type => type === "welcome" || type === "goodbye")
        )

        for (const plugin of Yowtech.plugins.getPlugins()) {
            if (typeof plugin?.onParticipantUpdate !== "function") continue
            try {
                await plugin.onParticipantUpdate({
                    sock,
                    db,
                    logger,
                    id,
                    participants,
                    action,
                    metadata
                })
            } catch (error) {
                logger?.error?.(error)
            }
        }

        for (const participant of participants) {
            const rawJid = memberIds(participant)[0]
            if (!rawJid) continue
            const jid = participantJid(participant, rawJid, metadata)

            if (action === "add" || action === "remove") {
                const type = action === "add" ? "welcome" : "goodbye"
                if (group[type] === true && !customEventTypes.has(type)) {
                    if (isDuplicateParticipantEvent(id, action, jid || rawJid)) {
                        continue
                    }

                    await sendGroupEventCard({
                        sock,
                        chat: id,
                        type,
                        groupName: metadata.subject || "WhatsApp Group",
                        userJid: jid,
                        userName: memberName(participant, rawJid, metadata, sock),
                        userNumber: displayPhone(participant, rawJid, metadata),
                        totalMembers: Array.isArray(metadata.participants) ? metadata.participants.length : 0,
                        intro
                    })
                }
                continue
            }

            if (action === "promote") {
                await sendLegacyView({
                    sock,
                    chat: id,
                    jid,
                    author,
                    metadata,
                    data: views.promote
                })
                continue
            }

            if (action === "demote") {
                await sendLegacyView({
                    sock,
                    chat: id,
                    jid,
                    author,
                    metadata,
                    data: views.demote
                })
            }
        }
    } catch (error) {
        logger?.error?.(error)
    }
}
