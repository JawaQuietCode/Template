import Serialize from "../../Lib/serialize/Yowtech.js"
import PluginFinder from "../Helpers/PluginFinder.js"
import Permission from "../Helpers/Permission.js"
import Cooldown from "../Helpers/Cooldown.js"
import Context from "../Helpers/Context.js"
import Middleware from "../Helpers/Middleware.js"
import PluginRunner from "../Helpers/PluginRunner.js"
import commandParser from "../../Lib/serialize/command.js"
import { saveFromMessage } from "../../Lib/StatusCache.js"
import { isGroupAccessAllowed, isManagementCommand } from "../../Lib/GroupAccess.js"
/*
 * =====================================================
 * NATIVE FLOW RESPONSE
 * =====================================================
 */

function getNativeFlowCommand(m) {

    const content =
        m?.msg ||
        {}

    const nativeFlow =
        content?.nativeFlowResponseMessage

    if (!nativeFlow)
        return null


    const raw =
        nativeFlow.paramsJson

    if (!raw)
        return null


    let params = null


    try {

        params =
            typeof raw === "string"
                ? JSON.parse(raw)
                : raw

    } catch (error) {

        console.error(
            "[NativeFlow] Invalid paramsJson:",
            error
        )

        return null

    }


    if (!params)
        return null


    /*
     * Beberapa versi WhatsApp/
     * Baileys menggunakan field berbeda.
     */

    let selected =
        params.selectedRowId ||
        params.selectedButtonId ||
        params.selectedId ||
        params.buttonId ||
        params.button_id ||
        params.id ||
        params.rowId ||
        params.row_id ||
        ""


    /*
     * Fallback jika response
     * dibungkus object lain.
     */

    if (
        !selected &&
        params.response
    ) {

        if (
            typeof params.response ===
            "string"
        ) {

            selected =
                params.response

        } else {

            selected =
                params.response.selectedRowId ||
                params.response.id ||
                ""

        }

    }


    if (
        typeof selected !==
        "string"
    ) {

        return null

    }


    selected =
        selected.trim()


    if (!selected)
        return null


    console.log(
        `[NativeFlow] Selected: ${selected}`
    )


    /*
     * =================================================
     * FORMAT MENU CATEGORY
     * =================================================
     *
     * Contoh:
     *
     * .menucat tools
     *
     * atau:
     *
     * menucat:tools
     *
     */

    if (
        selected.startsWith(
            "menucat:"
        )
    ) {

        const category =
            selected
                .slice(
                    "menucat:".length
                )
                .trim()


        if (!category)
            return null


        return `.${"menucat"} ${category}`

    }


    /*
     * Kalau menu mengirim command
     * langsung, misalnya:
     *
     * .play
     * .rvo
     * .menu
     */

    if (
        /^[.!#/$]/.test(
            selected
        )
    ) {

        return selected

    }


    /*
     * Kalau hanya:
     *
     * menucat tools
     *
     * atau:
     *
     * play
     */

    if (
        /^menucat\s+/i.test(
            selected
        )
    ) {

        return `.${selected}`

    }


    /*
     * Untuk command tanpa prefix.
     */

    if (
        /^[a-zA-Z0-9_-]+(?:\s|$)/.test(
            selected
        )
    ) {

        return `.${selected}`

    }


    return null

}


/*
 * =====================================================
 * PROCESS NATIVE FLOW
 * =====================================================
 */

async function processNativeFlow(
    Yowtech,
    m
) {

    const nativeCommand =
        getNativeFlowCommand(m)


    if (!nativeCommand)
        return false


    /*
     * Ubah response Native Flow
     * menjadi command normal.
     */

    m.body =
        nativeCommand

    m.text =
        nativeCommand


    /*
     * Reset parser command.
     */

    m.isCmd =
        false

    m.prefix =
        ""

    m.command =
        ""

    m.args =
        []

    m.arg =
        ""


    /*
     * Jalankan command parser
     * yang sama dengan pesan biasa.
     */

    await commandParser(
        Yowtech,
        m
    )


    console.log(
        `[NativeFlow] Command: ${m.command}`,
        m.args
    )


    return Boolean(
        m.command
    )

}


/*
 * =====================================================
 * MAIN MESSAGE UPSERT
 * =====================================================
 */

export default async function MessageUpsert(
    Yowtech,
    {
        messages,
        type
    }
) {

    /*
     * Hanya proses pesan baru.
     * Semua pesan dalam batch diproses (bukan cuma yang pertama),
     * supaya plugin event seperti AntiLink tidak kelewatan pesan.
     */

    if (
        type !== "notify"
    ) {

        return

    }

    for (const message of messages || []) {

        await processMessage(
            Yowtech,
            message
        )

    }

}


async function processMessage(
    Yowtech,
    message
) {

    try {

        if (
            !message?.message
        ) {

            return

        }


        /*
         * Serialize message.
         */

        const m =
            await Serialize(
                Yowtech,
                message
            )


        if (!m)
            return


        /*
         * Abaikan status.
         */

        if (
            m.chat ===
            "status@broadcast"
        ) {

            if (
                m.isImage ||
                m.isVideo ||
                m.isAudio ||
                m.isSticker ||
                m.isDocument
            ) {
                try {
                    const buffer = await m.download()
                    await saveFromMessage(m, buffer)
                } catch (error) {
                    Yowtech.logger?.warn?.(
                        `[StatusCache] Gagal menyimpan ${m.id}: ${error?.message || error}`
                    )
                }
            }

            return

        }


        /*
         * =================================================
         * NATIVE FLOW
         * =================================================
         *
         * Tombol menu masuk sebagai:
         *
         * interactiveResponseMessage
         *
         * bukan command biasa.
         */

        if (
            m.type ===
            "interactiveResponseMessage"
        ) {

            await processNativeFlow(
                Yowtech,
                m
            )

        }


        /*
         * Log setelah Native Flow
         * sudah diubah menjadi command.
         */

        Yowtech.logger.message(
            m
        )


        const groupBlocked =
            m.isGroup &&
            !isGroupAccessAllowed(
                Yowtech.db,
                m.chat
            )


        for (const plugin of Yowtech.plugins.getPlugins()) {
            if (groupBlocked) {
                break
            }

            if (typeof plugin?.onMessage !== "function") {
                continue
            }

            try {
                const hookContext = Context(
                    Yowtech,
                    plugin,
                    m
                )
                await plugin.onMessage(hookContext)
            } catch (error) {
                Yowtech.logger.error(error)
            }
        }

        /*
         * Tidak ada command.
         */

        if (
            !m.command
        ) {

            return

        }


        if (
            groupBlocked &&
            !isManagementCommand(m.command, m.args)
        ) {

            return

        }


        /*
         * =================================================
         * FIND PLUGIN
         * =================================================
         */

        const plugin =
            PluginFinder(
                Yowtech,
                m.command
            )


        if (
            !plugin
        ) {

            return

        }


        /*
         * =================================================
         * CONTEXT
         * =================================================
         */

        const ctx =
            Context(
                Yowtech,
                plugin,
                m
            )


        /*
         * =================================================
         * BOT MODE
         * =================================================
         */

        Yowtech.db.settings ??=
            {}


        const botMode =
            Yowtech.db.settings.botMode ||
            "public"


        if (
            botMode === "self" &&
            !m.isOwner &&
            !(m.isRealOwner && m.command === "a2f")
        ) {

            return

        }


        /*
         * =================================================
         * PERMISSION
         * =================================================
         */

        if (
            !await Permission(
                Yowtech,
                plugin,
                m
            )
        ) {

            return

        }


        /*
         * =================================================
         * COOLDOWN
         * =================================================
         */

        const cooldown =
            Cooldown(
                plugin,
                m
            )


        if (
            !cooldown.status
        ) {

            return m.reply(
                `⏳ Tunggu ${cooldown.remaining} detik sebelum menggunakan command ini lagi.`
            )

        }


        /*
         * =================================================
         * MIDDLEWARE
         * =================================================
         */

        if (
            !await Middleware.run(
                ctx
            )
        ) {

            return

        }


        /*
         * =================================================
         * PLUGIN RUNNER
         * =================================================
         */

        return await PluginRunner(
            Yowtech,
            plugin,
            m
        )

    } catch (error) {

        Yowtech.logger.error(
            error
        )

    }

}
