import PluginHooks from "../Helpers/PluginHooks.js"
import { remove as removeStatus } from "../../Lib/StatusCache.js"

export default async function MessagesDelete(Yowtech, updates) {
    const { logger } = Yowtech

    try {
        if (!Array.isArray(updates)) {
            updates = [updates]
        }

        for (const update of updates) {
            const { keys = [] } = update

            for (const key of keys) {
                logger.info(
                    `[Message Deleted] ${key.remoteJid} | ${key.id}`
                )

                if (key.remoteJid === "status@broadcast") {
                    await removeStatus(`status@broadcast:${key.id}`)
                }

                // Hook plugin: onMessageDelete({ key, update })
                await PluginHooks(Yowtech, "onMessageDelete", {
                    key,
                    update
                })
            }
        }

    } catch (error) {
        logger.error(error)
    }
}
