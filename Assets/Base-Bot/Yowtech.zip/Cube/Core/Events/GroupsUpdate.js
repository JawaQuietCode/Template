export default async function GroupsUpdate(Yowtech, updates) {
    const { logger } = Yowtech

    try {
        for (const update of updates) {
            const {
                id,
                subject,
                desc,
                announce,
                restrict,
                memberAddMode,
                joinApprovalMode
            } = update

            logger.info(`Group Updated: ${id}`)

            for (const plugin of Yowtech.plugins?.getPlugins?.() || []) {
                if (typeof plugin?.onGroupUpdate !== "function") continue
                try {
                    await plugin.onGroupUpdate({
                        sock: Yowtech.sock,
                        db: Yowtech.db,
                        logger,
                        update
                    })
                } catch (error) {
                    logger?.error?.(error)
                }
            }

            if (subject !== undefined) {
                logger.info(`Subject : ${subject}`)
            }

            if (desc !== undefined) {
                logger.info("Description diperbarui.")
            }

            if (announce !== undefined) {
                logger.info(
                    `Mode Chat : ${announce ? "Admin Only" : "Everyone"}`
                )
            }

            if (restrict !== undefined) {
                logger.info(
                    `Edit Info : ${restrict ? "Admin Only" : "Everyone"}`
                )
            }

            if (memberAddMode !== undefined) {
                logger.info(
                    `Member Add Mode : ${memberAddMode}`
                )
            }

            if (joinApprovalMode !== undefined) {
                logger.info(
                    `Join Approval : ${joinApprovalMode}`
                )
            }
        }

    } catch (error) {
        logger.error(error)
    }
}
