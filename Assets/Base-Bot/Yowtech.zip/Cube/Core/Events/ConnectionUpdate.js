import { Boom } from "@hapi/boom"
import { rm } from "node:fs/promises"
import path from "node:path"
import PluginHooks from "../Helpers/PluginHooks.js"

const reconnectTimers = new WeakMap()
const restartingSockets = new WeakSet()
const MAIN_SESSION_DIR = path.resolve(process.cwd(), "session")

function wait(ms) {
    return new Promise(resolve => setTimeout(resolve, ms))
}

export default async function ConnectionUpdate(Yowtech, update = {}) {
    const { sock, logger, start, connectionControl } = Yowtech
    const label = Yowtech.jadibotPhone ? `[JadiBot ${Yowtech.jadibotPhone}] ` : ""
    const { connection, lastDisconnect } = update

    // Hook plugin: onConnectionUpdate({ update, connection, lastDisconnect })
    await PluginHooks(Yowtech, "onConnectionUpdate", {
        update,
        connection,
        lastDisconnect
    })

    if (connection === "connecting") {
        logger.info(`${label}Menghubungkan ke WhatsApp...`)
        return
    }

    if (connection === "open") {
        const timer = reconnectTimers.get(sock)
        if (timer) clearTimeout(timer)
        reconnectTimers.delete(sock)
        if (connectionControl) {
            connectionControl.hasOpened = true
            connectionControl.pairing = false
        }
        logger.success(`${label}Berhasil terhubung ke WhatsApp.`)
        return
    }

    if (connection !== "close" || connectionControl?.stopping) return

    if (connectionControl?.pairing || (
        connectionControl &&
        !connectionControl.sessionRegistered &&
        !connectionControl.hasOpened
    )) {
        logger.warn(
            `${label}Koneksi pairing awal terputus. Session tidak dihapus dan restart otomatis dilewati.`
        )
        return
    }

    if (restartingSockets.has(sock)) return
    restartingSockets.add(sock)

    const reason = new Boom(lastDisconnect?.error).output?.statusCode
    logger.warn(
        `${label}Koneksi close${reason ? ` (reason ${reason})` : ""}. Session akan dihapus dan bot dimulai ulang.`
    )

    try {
        if (!Yowtech.jadibotPhone) {
            await rm(MAIN_SESSION_DIR, {
                recursive: true,
                force: true,
                maxRetries: 3,
                retryDelay: 250
            })
            logger.warn(`${label}Folder session utama dihapus: ${MAIN_SESSION_DIR}`)
        } else {
            logger.warn(`${label}Session JadiBot tidak dihapus oleh handler utama.`)
        }
    } catch (error) {
        logger.error(`${label}Gagal menghapus session: ${error?.message || error}`)
    }

    if (typeof start !== "function") {
        logger.error(`${label}Restart dibatalkan karena fungsi start tidak tersedia.`)
        restartingSockets.delete(sock)
        return
    }

    const timer = setTimeout(async () => {
        reconnectTimers.delete(sock)
        try {
            for (let attempt = 1; attempt <= 3; attempt += 1) {
                if (connectionControl?.stopping) return
                try {
                    await start()
                    logger.success(`${label}Restart otomatis berhasil.`)
                    return
                } catch (error) {
                    logger.error(`${label}Restart ${attempt}/3 gagal: ${error?.message || error}`)
                    if (attempt < 3) await wait(attempt * 3000)
                }
            }

            logger.error(`${label}Restart otomatis gagal setelah 3 percobaan.`)
        } finally {
            restartingSockets.delete(sock)
        }
    }, 1000)

    reconnectTimers.set(sock, timer)
}
