import PluginHooks from "../Helpers/PluginHooks.js"

export default async function ContactsUpdate(Yowtech, updates) {
    const { store, logger } = Yowtech

    try {
        // Hook plugin: onContactsUpdate({ updates })
        await PluginHooks(Yowtech, "onContactsUpdate", { updates })

        if (!store) return

        store.contacts ??= {}

        for (const contact of updates) {
            if (!contact?.id) continue

            store.contacts[contact.id] = {
                ...(store.contacts[contact.id] || {}),
                ...contact
            }
        }

        logger.info(`Contacts synced: ${updates.length}`)

    } catch (error) {
        logger.logError(error)
    }
}
