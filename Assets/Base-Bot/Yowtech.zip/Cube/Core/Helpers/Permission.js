export default async function Permission(Yowtech, plugin, m) {

    const permission =
        plugin.permission || {}

    const db =
        Yowtech.db

    db.settings ??= {}

    const ownerHasAdminAccess =
        db.settings.a2f === true &&
        m.isOwner === true

    // ==========================
    // OWNER
    // ==========================

    const ownerMode =
        db.settings.ownerMode ??
        "owner"

    const bypassOwnerMode = [
        "Chose",
        "A2F"
    ]

    const allowOwner =

        bypassOwnerMode.includes(
            plugin.name
        )

            ? m.isRealOwner

            : (
                m.isOwner &&
                ownerMode === "owner"
            )

    if (
        permission.owner &&
        !allowOwner
    ) {

        await m.reply(
            "⚠️ Perintah ini hanya dapat digunakan oleh Owner."
        )

        return false

    }

    // ==========================
    // GROUP
    // ==========================

    if (
        permission.group &&
        !m.isGroup
    ) {

        await m.reply(
            "⚠️ Perintah ini hanya dapat digunakan di dalam Grup."
        )

        return false

    }

    // ==========================
    // PRIVATE
    // ==========================

    if (
        permission.private &&
        m.isGroup
    ) {

        await m.reply(
            "⚠️ Perintah ini hanya dapat digunakan di Private Chat."
        )

        return false

    }

    // ==========================
    // ADMIN
    // ==========================

    if (
        permission.admin &&
        !m.isAdmin &&
        !ownerHasAdminAccess
    ) {

        await m.reply(
            "⚠️ Perintah ini hanya dapat digunakan oleh Admin Grup."
        )

        return false

    }

    // ==========================
    // BOT ADMIN
    // ==========================

    if (
        permission.botAdmin &&
        !m.isBotAdmin
    ) {

        await m.reply(
            "⚠️ Bot harus menjadi Admin terlebih dahulu."
        )

        return false

    }

    // ==========================
    // PREMIUM
    // ==========================

    if (
        permission.premium &&
        !m.isPremium
    ) {

        await m.reply(
            "⚠️ Perintah ini hanya untuk pengguna Premium."
        )

        return false

    }

    return true

}
