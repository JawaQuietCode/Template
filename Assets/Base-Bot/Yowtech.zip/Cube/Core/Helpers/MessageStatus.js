import fs from "node:fs/promises"
import path from "node:path"
import { fileURLToPath } from "node:url"
import sharp from "sharp"

const PROJECT_ROOT = path.resolve(
    path.dirname(fileURLToPath(import.meta.url)),
    "..",
    "..",
    ".."
)

const STATUS_CONFIG = {
    success: {
        label: "SUCCESS",
        icon: "✅",
        file: "Success.png",
        title: "Command Berhasil",
        fallback: "Perintah berhasil dijalankan."
    },
    error: {
        label: "ERROR",
        icon: "❌",
        file: "Error.png",
        title: "Command Error",
        fallback: "Terjadi kesalahan saat menjalankan perintah."
    },
    pending: {
        label: "PENDING",
        icon: "⏳",
        file: "Pending.png",
        title: "Command Diproses",
        fallback: "Perintah sedang diproses."
    }
}

const imageCache = new Map()
const FALLBACK_STATUS_IMAGE = path.join(PROJECT_ROOT, "Assets", "Images", "Info.png")

function normalizeStatus(status) {
    const key = String(status || "").trim().toLowerCase()
    if (["success", "sukses", "berhasil", "ok", "true"].includes(key)) return "success"
    if (["error", "gagal", "failed", "fail", "false"].includes(key)) return "error"
    if (["pending", "proses", "processing", "loading"].includes(key)) return "pending"
    throw new Error(`Status tidak dikenal: ${status}`)
}

function resolveStatusImage(config) {
    return path.join(PROJECT_ROOT, "Assets", "Images", config.file)
}

async function getStatusImage(config) {
    const imagePath = resolveStatusImage(config)
    if (imageCache.has(imagePath)) return imageCache.get(imagePath)

    let image
    try {
        image = await fs.readFile(imagePath)
    } catch {
        image = await fs.readFile(FALLBACK_STATUS_IMAGE)
    }
    imageCache.set(imagePath, image)
    return image
}

async function getThumbnail(image) {
    return sharp(image)
        .resize(300, 300, {
            fit: "inside",
            withoutEnlargement: true
        })
        .jpeg({ quality: 82 })
        .toBuffer()
}

function getBotInfo() {
    return {
        name: global.yB?.botName || "Bot",
        version: global.yB?.botVersion || "1.0.0",
        developer: global.yB?.ownerName || process.env.BOT_DEVELOPER || "Developer"
    }
}

function getTime() {
    return new Intl.DateTimeFormat("id-ID", {
        timeZone: process.env.BOT_TIMEZONE || "Asia/Jakarta",
        hour: "2-digit",
        minute: "2-digit",
        hour12: false
    }).format(new Date())
}

function buildCaption(config, message, bot) {
    const text = String(message || config.fallback).trim()

    return [
        `╭─〔 ${config.icon} *${config.label}* 〕`,
        `│ ${text}`,
        "╰──────────────",
        "",
        `Bot     : ${bot.name}`,
        `Version : ${bot.version}`,
        `Time    : ${getTime()}`,
        `Dev     : ${bot.developer}`
    ].join("\n")
}

function getSourceUrl() {
    return global.yB?.channelUrl || "https://wa.me/"
}

/**
 * Mengirim status standar dengan gambar status dan FakeAd.
 * Gambar status memakai Assets/Images dengan fallback Info.png
 *
 * @param {object} ctx Context plugin dari framework
 * @param {"success"|"error"|"pending"} status Status pesan
 * @param {string} message Isi status
 * @param {object} options Opsi tambahan pengiriman
 * @returns {Promise<object>} Hasil sendMessage
 */
export default async function MessageStatus(ctx, status, message, options = {}) {
    const key = normalizeStatus(status)
    const config = STATUS_CONFIG[key]
    const bot = getBotInfo()
    const image = await getStatusImage(config)
    const thumbnail = await getThumbnail(image)
    const caption = buildCaption(config, message, bot)

    return ctx.sock.sendMessage(
        ctx.m.chat,
        {
            image,
            mimetype: "image/png",
            fileName: `${config.label}.png`,
            caption,
            jpegThumbnail: thumbnail,
            contextInfo: {
                ...(options.contextInfo || {}),
                externalAdReply: {
                    title: config.title,
                    body: `${bot.name} | ${bot.version} | ${bot.developer}`,
                    mediaType: 1,
                    renderLargerThumbnail: true,
                    showAdAttribution: true,
                    sourceUrl: options.sourceUrl || getSourceUrl(),
                    thumbnail
                }
            }
        },
        {
            quoted: options.quoted || ctx.m
        }
    )
}

export const statusSuccess = (ctx, message, options) =>
    MessageStatus(ctx, "success", message, options)

export const statusError = (ctx, message, options) =>
    MessageStatus(ctx, "error", message, options)

export const statusPending = (ctx, message, options) =>
    MessageStatus(ctx, "pending", message, options)

//━━━━━━━━━━━━━━━━━━━━//
// AUTO-DISPATCH DARI RETURN VALUE PLUGIN
//━━━━━━━━━━━━━━━━━━━━//
/*
 * Ini yang bikin plugin cukup `return { success: true }` atau
 * `return { success: false, message: "..." }` tanpa manual
 * import/panggil statusSuccess/statusError sendiri.
 *
 * Konvensi return value plugin (semua opsional):
 *   { success: true, message?: string, options?: object }
 *   { success: false, message?: string, error?: Error, options?: object }
 *   { status: "pending" | "success" | "error", message?: string }
 *   { silent: true }  → skip total, plugin sudah kirim pesannya sendiri
 *
 * Kalau execute() tidak return apa-apa (undefined) atau bukan
 * object, tidak ada status yang dikirim otomatis — dianggap
 * plugin sudah menangani balasannya sendiri.
 */
export async function handlePluginResult(ctx, result) {
    if (!result || typeof result !== "object") return result
    if (result.silent === true) return result

    let key = null

    if (typeof result.status === "string") {
        key = result.status
    } else if (typeof result.success === "boolean") {
        key = result.success ? "success" : "error"
    }

    if (!key) return result

    try {
        const normalized = normalizeStatus(key)
        const message =
            result.message ||
            result.error?.message ||
            (typeof result.error === "string" ? result.error : undefined)

        await MessageStatus(ctx, normalized, message, result.options || {})
    } catch (error) {
        ctx.logger?.error?.(error)
    }

    return result
}

export { STATUS_CONFIG }
