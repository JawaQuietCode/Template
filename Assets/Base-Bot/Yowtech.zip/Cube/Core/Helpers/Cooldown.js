const cooldowns = new Map()

export default function Cooldown(plugin, m) {
    // Owner bypass
    if (m.isOwner) {
    return {
        status: true,
        remaining: 0
    }
}

    const seconds = plugin.cooldown ?? 3

    if (seconds <= 0) return {
        status: true,
        remaining: 0
    }

    const key = `${m.sender}:${plugin.name}`
    const now = Date.now()

    const expires = cooldowns.get(key)

    if (expires && expires > now) {
        return {
            status: false,
            remaining: Math.ceil((expires - now) / 1000)
        }
    }

    cooldowns.set(key, now + seconds * 1000)

    setTimeout(() => {
        cooldowns.delete(key)
    }, seconds * 1000)

    return {
        status: true,
        remaining: 0
    }
}
