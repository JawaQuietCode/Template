const middlewares = []

export function use(callback) {
    if (typeof callback !== "function") return

    middlewares.push(callback)
}

export async function run(ctx) {
    for (const middleware of middlewares) {
        const result = await middleware(ctx)

        if (result === false) {
            return false
        }
    }

    return true
}

export default {
    use,
    run
}
