export default function Context(Yowtech, plugin, m) {

    return {

        // Core
        sock: Yowtech.sock,
        db: Yowtech.db,
        store: Yowtech.store,
        logger: Yowtech.logger,
        plugins: Yowtech.plugins,
        messageEvents: Yowtech.messageEvents,
        jadibotManager: Yowtech.jadibotManager,

        // Plugin
        plugin,

        // Message
        m,

        // Command
        command: m.command,
        prefix: m.prefix,
        args: m.args,

        // Text
        text: m.text,

        // Shortcut
        chat: m.chat,
        sender: m.sender,
        number: m.number,
        quoted: m.quoted,

        // Permission
        isOwner: m.isOwner,
        isPartner: m.isPartner,
        isPremium: m.isPremium,
        isAdmin: m.isAdmin,
        isBotAdmin: m.isBotAdmin,
        isGroup: m.isGroup

    }

}
