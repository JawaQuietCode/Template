import Context from "./Context.js"
import ErrorHandler from "./ErrorHandler.js"
import { handlePluginResult } from "./MessageStatus.js"

export default async function PluginRunner(Yowtech, plugin, m) {
    const ctx = Context(Yowtech, plugin, m)

    // Reaction awal, tanda command sudah terbaca & mulai diproses.
    // Beberapa command seperti .good mengelola reaction-nya sendiri.
    if (!plugin.skipAutoReactionCommands?.includes(m.command)) {
        ctx.m.react("🪐").catch(() => {})
    }

    try {
        const result = await plugin.execute(ctx)
        await handlePluginResult(ctx, result)
        return result
    } catch (error) {
        await ErrorHandler(Yowtech, error, ctx)
    }
}
