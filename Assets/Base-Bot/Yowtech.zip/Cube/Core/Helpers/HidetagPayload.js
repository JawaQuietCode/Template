import sharp from "sharp"
import { uniqueMentionJids } from "../../Lib/MentionJid.js"

const URL_PATTERN = /https?:\/\/[^\s<>]+/i

export function findFirstUrl(text = "") {
    return String(text).match(URL_PATTERN)?.[0] || null
}

async function fetchBytes(url) {
    const response = await fetch(url, {
        redirect: "follow",
        headers: { "user-agent": "WhatsApp/2.24.10" }
    })
    if (!response.ok) throw new Error(`HTTP ${response.status}`)
    return Buffer.from(await response.arrayBuffer())
}

function extractMeta(html, property, name) {
    const escaped = property.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")
    const pattern = new RegExp(`<meta[^>]+(?:property=["']${escaped}["']|name=["']${name}["'])[^>]+content=["']([^"']+)["'][^>]*>`, "i")
    return html.match(pattern)?.[1] || null
}

export async function getUrlThumbnail(url) {
    if (!url) return null

    try {
        const html = await (await fetch(url, {
            redirect: "follow",
            headers: { "user-agent": "WhatsApp/2.24.10" }
        })).text()

        const imageUrl = extractMeta(html, "og:image", "twitter:image")
        if (!imageUrl) return null

        const absoluteImage = new URL(imageUrl, url).href
        const raw = await fetchBytes(absoluteImage)
        const jpegThumbnail = await sharp(raw)
            .resize(640, 640, { fit: "inside", withoutEnlargement: true })
            .jpeg({ quality: 80 })
            .toBuffer()

        return { url, imageUrl: absoluteImage, jpegThumbnail }
    } catch {
        return null
    }
}

export function getReplyText(quoted) {
    const message = quoted?.message || {}
    return message.conversation ||
        message.extendedTextMessage?.text ||
        message.imageMessage?.caption ||
        message.videoMessage?.caption ||
        message.documentMessage?.caption ||
        ""
}

export async function buildHidetagContent({ text, participants, withThumbnail }) {
    const url = findFirstUrl(text)
    const thumbnail = withThumbnail ? await getUrlThumbnail(url) : null
    const mentionJids = uniqueMentionJids(participants)
    const contextInfo = { mentionedJid: mentionJids }

    if (thumbnail?.jpegThumbnail) {
        return {
            image: thumbnail.jpegThumbnail,
            caption: text,
            mentions: mentionJids,
            contextInfo
        }
    }

    return {
        text,
        mentions: mentionJids,
        contextInfo
    }
}
