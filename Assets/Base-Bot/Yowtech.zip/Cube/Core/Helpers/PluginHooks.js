/*
 * Menjalankan hook event pada semua plugin yang punya hook tersebut.
 *
 * Contoh di plugin:
 *   export default {
 *       name: "AntiLink",
 *       onMessage: async (ctx) => { ... }
 *   }
 *
 * Satu plugin yang error tidak menghentikan plugin lain.
 */
export default async function PluginHooks(Yowtech, hook, payload = {}) {
    const list = Yowtech.plugins?.getPlugins?.() || []

    for (const plugin of list) {
        if (typeof plugin?.[hook] !== "function") continue

        try {
            await plugin[hook]({
                sock: Yowtech.sock,
                db: Yowtech.db,
                store: Yowtech.store,
                logger: Yowtech.logger,
                plugins: Yowtech.plugins,
                jadibotManager: Yowtech.jadibotManager,
                plugin,
                ...payload
            })
        } catch (error) {
            Yowtech.logger?.error?.(error)
        }
    }
}
