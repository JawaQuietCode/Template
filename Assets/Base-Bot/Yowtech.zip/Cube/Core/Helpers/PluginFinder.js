export default function PluginFinder(Yowtech, command) {
    const { plugins } = Yowtech

    if (!command) return null

    return plugins.getPlugin(command)
}
