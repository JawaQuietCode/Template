export default async function ErrorHandler(Yowtech, error, ctx = {}) {
    const { logger } = Yowtech
    const config = Yowtech.config ?? {}
    const { m, plugin } = ctx

    logger?.error(error)

    if (!m) return

    const message =
        config.message?.error ??
        "Terjadi kesalahan saat menjalankan perintah."

    try {
        await m.reply(message)

        if (config.debug && error?.stack) {
            await m.reply(`\`\`\`\n${error.stack}\n\`\`\``)
        }
    } catch (replyError) {
        // Jangan biarkan gagal-kirim-reply ikut membuat
        // seluruh MessageUpsert diam tanpa jejak.
        logger?.error(replyError)
    }
}
