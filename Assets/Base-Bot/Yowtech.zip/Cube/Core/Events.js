import MessageUpsert from "./Events/MessageUpsert.js"
import ConnectionUpdate from "./Events/ConnectionUpdate.js"

import GroupParticipants from "./Events/GroupParticipants.js"
import GroupsUpdate from "./Events/GroupsUpdate.js"

import ContactsUpdate from "./Events/ContactsUpdate.js"
import PresenceUpdate from "./Events/PresenceUpdate.js"

import MessagesDelete from "./Events/MessagesDelete.js"
import MessagesReaction from "./Events/MessagesReaction.js"

import Call from "./Events/Call.js"

export default {
    "messages.upsert": MessageUpsert,

    "connection.update": ConnectionUpdate,

    "group-participants.update": GroupParticipants,
    "groups.update": GroupsUpdate,

    "contacts.update": ContactsUpdate,
    "presence.update": PresenceUpdate,

    "messages.delete": MessagesDelete,
    "messages.reaction": MessagesReaction,

    "call": Call
}
