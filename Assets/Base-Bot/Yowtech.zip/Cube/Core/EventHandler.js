import Events from "./Events.js"

export default function EventHandler(Yowtech) {
    const { sock, logger } = Yowtech

    for (const [event, handler] of Object.entries(Events)) {
        sock.ev.on(event, async (...args) => {
            try {
                await handler(Yowtech, ...args)
            } catch (error) {
                logger.error(error)
            }
        })
    }
}
